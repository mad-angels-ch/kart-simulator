from .Circle import Circle


class FireBall(Circle):
    """Classe des boules de feu. Le principe est simple: dès qu'un kart touche la boule de feu, il a perdu!"""
