import lib


class Fill:
    """Classe abstrate indiquant la méthode de remplissage d'un objet"""

    def type(self) -> str:
        """Retourne la méthode de remplissage de l'objet"""
