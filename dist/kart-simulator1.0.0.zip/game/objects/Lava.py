from .Polygon import Polygon


class Lava(Polygon):
    """Classe de la lave. Le principe est simple: dès qu'un kart touche la lave, il a perdu!"""
