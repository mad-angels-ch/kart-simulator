from kivy.uix.floatlayout import FloatLayout
from kivy.lang import Builder

Builder.load_file("client/output/screens/create_or_join.kv")

class CreateOrJoin(FloatLayout):
    pass