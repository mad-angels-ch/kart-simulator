from kivy.uix.floatlayout import FloatLayout
from kivy.lang import Builder

Builder.load_file("client/output/screens/credits.kv")

class Credits(FloatLayout):
    pass