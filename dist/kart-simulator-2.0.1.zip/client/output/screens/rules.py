from kivy.uix.floatlayout import FloatLayout
from kivy.lang import Builder

Builder.load_file("client/output/screens/rules.kv")

class Rules(FloatLayout):
    pass